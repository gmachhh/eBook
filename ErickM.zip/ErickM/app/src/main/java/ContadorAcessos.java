public class ContadorAcessos {
    private static ContadorAcessos instancia;
    private int value = 0;
    private ContadorAcessos(){}
    public static ContadorAcessos getInstance(){
        if (instancia==null){
            instancia = new ContadorAcessos();
        }
        return instancia;
    }
    public void incrementar(){
        value++;
    }

    public int getTotal(){
        return value;
    }
}

