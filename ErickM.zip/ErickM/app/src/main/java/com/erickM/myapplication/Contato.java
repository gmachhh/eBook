package com.erickM.myapplication;

import java.io.Serializable;

public class Contato implements Serializable {

    private String nome;
    private String telefone;
    private String email;
    private String instagram;

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setInstagram(String instagram) {
        this.instagram = instagram;
    }

    public String getNome() {return nome;}
    public String getEmail() {return email;}
    public String getTelefone() {return telefone;}
    public String getInstagram() {return instagram;}
}

