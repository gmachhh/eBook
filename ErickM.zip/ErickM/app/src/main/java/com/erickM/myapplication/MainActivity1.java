package com.erickM.myapplication;

import android.content.Intent;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity1 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Contato contato = new Contato();
        if (getIntent().hasExtra("contato")){
            Object parametro = getIntent().getExtras().get("contato");

            contato = (Contato) parametro;

            Toast.makeText(this, "Carregou...", Toast.LENGTH_SHORT).show();
        }


        setContentView(R.layout.activity_main);
        TextView nome = findViewById(R.id.main_activity_nome);
        nome.setText(contato.getNome());
        nome.setPaintFlags(nome.getPaintFlags() | Paint.UNDERLINE_TEXT_FLAG);
        TextView telefone = findViewById(R.id.main_activity_tel);
        telefone.setText(contato.getTelefone());
        TextView email = findViewById(R.id.main_activity_email);
        email.setText(contato.getEmail());
        TextView insta = findViewById(R.id.main_activity_insta);
        insta.setText(contato.getInstagram());
        TextView face = findViewById(R.id.main_activity_face);
        TextView twit = findViewById(R.id.main_activity_twt);

        telefone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_DIAL,
                        Uri.parse("tel:11940034087"));
                startActivity(intent);
            }
        });

        email.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_SENDTO,
                        Uri.parse("mailto:erick2006mach@gmail.com"));
                intent.putExtra(Intent.EXTRA_SUBJECT, "Conseguiu!");
                startActivity(intent);
            }
        });

        insta.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW,
                        Uri.parse("https://www.instagram.com/erickgmachz/?next=%2F"));
                startActivity(intent);
            }
        });

        face.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW,
                        Uri.parse("https://www.facebook.com/erick.machado.7967"));
                startActivity(intent);

            }
        });

        twit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW,
                        Uri.parse("https://x.com/ErickMa22928842"));
                startActivity(intent);

            }
        });

    }
}
