package com.erickM.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.List;

public class MainActivity2 extends AppCompatActivity {

    List<Contato> contatos = new ArrayList<>();
    ListView Lista = null;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        Lista = findViewById(R.id.activity_main2_list);

        Contato contato = new Contato();
        contato.setNome("Erick");
        contato.setEmail("erick2006mach@gmail.com");
        contato.setTelefone("11940034087");
        contato.setInstagram("erickgmachz");
        contatos.add(contato);
        atualizarLista();

        Lista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                Contato contato1 = contatos.get(position);
                Intent intent = new Intent(getBaseContext(), MainActivity.class);
                intent.putExtra("contatos",contato1);
                startActivity(intent);
            }
        });


        Button novo = findViewById(R.id.activity_main2_btn);
        novo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Contato novo = new Contato();
                novo.setNome("Ellen Vitória");
                novo.setEmail("ellen2005vit@gmail.com");
                novo.setTelefone("11930028596");
                novo.setInstagram("itzellen");
                contatos.add(novo);
                atualizarLista();
            }
        });
    }

    private void atualizarLista(){
        String nomes[] = new String[contatos.size()];

        for(int i=0;i<contatos.size();i++){
            nomes[i] = contatos.get(i).getNome();

        }
        ArrayAdapter<String> adapter =
                new ArrayAdapter<>(this,
                        android.R.layout.simple_list_item_1,
                        nomes);
        Lista.setAdapter(adapter);
    }
}
