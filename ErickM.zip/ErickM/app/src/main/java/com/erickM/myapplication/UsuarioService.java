package com.erickM.myapplication;

public class UsuarioService {
    public Contato login(Contato user){
        if(user.getEmail().equals("joao@ifsp.edu.br")
                && user.getSenha().equals("123")){
            user.setNome("João");
            return user;
        }
        return null;
    }
}


